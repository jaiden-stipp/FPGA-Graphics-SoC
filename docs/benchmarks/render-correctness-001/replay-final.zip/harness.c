
#include <stdint.h>
#include <stddef.h>
#include "world.h"
#include "gfx_protocol.h"
void *memcpy(void *d,const void *s,size_t n){unsigned char *a=d;const unsigned char *b=s;for(size_t i=0;i<n;++i)a[i]=b[i];return d;}
#define PORTABLE_DATA_DEFINE 1
#include "replay_world.h"
extern volatile uint32_t world_visible_chunks,world_gpu_chunks,world_uploaded_chunks,world_fallback_chunks;
static uint8_t stream[2000000];static uint32_t used;static player_t player;static uint32_t area_index;
static camera_orbit_t camera;static camera_orbit_config_t camera_config={1000,125,20,1000,2,3,16};
static int16_t camera_view[12],render_view[12];static uint32_t auto_camera;
static void camera_tick(void){if(auto_camera){camera_world_t cw={world_areas[area_index].camera_surfaces,world_areas[area_index].camera_count};camera_orbit_step(&camera,&player,&camera_config,&cw,camera_view,4);}}
static int raw(uint8_t op,const uint8_t *p,uint8_t n){if(used+2u+n>sizeof(stream))return -1;stream[used++]=op;stream[used++]=n;for(uint32_t i=0;i<n;++i)stream[used++]=p[i];return 0;}
int gfx_command(uint8_t op,const uint8_t *p,uint8_t n){return raw(op,p,n);}
static void word(uint8_t *p,int32_t v){p[0]=(uint8_t)((uint16_t)v>>8);p[1]=(uint8_t)v;}
int gfx_define_mesh(uint8_t h,uint16_t v,uint16_t t){uint8_t p[5]={h};word(p+1,v);word(p+3,t);return raw(GFX_OP_DEFINE_MESH,p,5);}
int game_mesh_frame(uint8_t h,const scene_vertex_t *v,uint32_t n){for(uint32_t i=0;i<n;++i){uint8_t p[8]={h,(uint8_t)i};word(p+2,v[i].x);word(p+4,v[i].y);word(p+6,v[i].z);if(raw(GFX_OP_UPLOAD_VERTEX,p,8))return -1;}return 0;}
int gfx_draw_matrix(uint8_t h,const int16_t *m){uint8_t p[25]={h};for(uint32_t i=0;i<12;++i)word(p+1+2*i,m[i]);return raw(GFX_OP_DRAW_MESH,p,25);}
void replay_reset(uint32_t a){area_index=a;used=0;camera.initialized=0;auto_camera=0;world_select(world_areas+a,&player);}
void replay_camera(const int16_t *v,int32_t distance){for(uint32_t i=0;i<12;++i)camera_view[i]=v[i];camera_config.distance=distance;auto_camera=1;}
void replay_view(int16_t *v){for(uint32_t i=0;i<12;++i)v[i]=render_view[i];}
void replay_step(uint32_t mask,uint32_t ticks){for(uint32_t i=0;i<ticks;++i){world_collision(world_areas+area_index,&player);player_step(&player,world_areas[area_index].physics,mask);camera_tick();}}
int replay_frame(const int16_t *view,uint32_t reserved,uint32_t id){
 camera_tick();if(auto_camera)view=camera_view;for(uint32_t i=0;i<12;++i)render_view[i]=view[i];
 used=0;if(world_prepare(world_areas+area_index,&player,view,reserved))return -1;
 uint8_t p[4]={(uint8_t)(id>>24),(uint8_t)(id>>16),(uint8_t)(id>>8),(uint8_t)id};if(raw(GFX_OP_BEGIN_FRAME,p,4))return -1;
 if(world_draw(world_areas+area_index,&player,view,reserved))return -1;return raw(GFX_OP_END_FRAME,p,0);
}
uint32_t replay_size(void){return used;}
const uint8_t *replay_data(void){return stream;}
void replay_state(int32_t *out){const int32_t *p=(const int32_t *)&player;for(uint32_t i=0;i<8;++i)out[i]=p[i];out[8]=(int32_t)world_visible_chunks;out[9]=(int32_t)world_gpu_chunks;out[10]=(int32_t)world_uploaded_chunks;out[11]=(int32_t)world_fallback_chunks;}
