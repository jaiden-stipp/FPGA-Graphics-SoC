#include <stdint.h>
extern uint32_t test_registers[64];
#define SOC_REG(offset) test_registers[(offset)/4]
