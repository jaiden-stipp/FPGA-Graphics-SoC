
#include "castle_game.c"
#include "gfx_protocol.h"
uint32_t test_registers[64];
static int active,errors,commands;
int gfx_identity_view(void){if(active)++errors;return 0;}
int gfx_begin_frame(uint32_t frame){(void)frame;if(active)++errors;active=1;return 0;}
int gfx_end_frame(void){if(!active)++errors;active=0;return 0;}
int gfx_define_mesh(uint8_t h,uint16_t v,uint16_t t){(void)h;(void)v;(void)t;if(active)++errors;return 0;}
int gfx_draw_matrix(uint8_t h,const int16_t v[12]){(void)h;(void)v;if(!active)++errors;++commands;return 0;}
int gfx_command(uint8_t op,const uint8_t *bytes,uint8_t n){(void)bytes;(void)n;if(op==GFX_OP_DRAW_TRIANGLE && !active)++errors;++commands;return 0;}
void test_init(void){active=errors=commands=0;game_port_init();}
void test_place(uint32_t area,int32_t x,int32_t y,int32_t z){int16_t arrival[3]={(int16_t)x,(int16_t)y,(int16_t)z};enter_area(area,arrival,0);camera_update();render_capture(1);}
void test_position(int32_t x,int32_t y,int32_t z){player.x=x;player.y=y;player.z=z;player.velocity_y=0;player.grounded=0;}
void test_input(uint32_t word){game_port_update(word);}
int32_t test_state(uint32_t field){switch(field){case 0:return player.x;case 1:return player.y;case 2:return player.z;case 3:return (int32_t)current_area;case 4:return (int32_t)player.grounded;case 5:return (int32_t)controller.action;case 6:return (int32_t)player.respawns;case 7:return (int32_t)pending_event;case 8:return errors;case 9:return commands;default:return -1;}}
int test_render(void){return game_port_render(1);}
int32_t test_floor(uint32_t area,int32_t x,int32_t z,int32_t ceiling){player_t p={0};p.x=x;p.z=z;p.y=ceiling;world_collision(world_areas+area,&p);return player_floor(world_areas[area].physics,x,z,ceiling);}
