// Castle traversal foundation. Original actor/terrain/collision data; scoped
// walking controller. Original SM64 slide actions and mission are not yet ported.
#include "soc.h"
#include "cpu_profile.h"
#include "gfx.h"
#include "game_port.h"
#include "game_services.h"
#include "world_data.h"
#include "castle_actor_data.h"
#include "castle_transitions.h"
#include "castle_rules.h"
#include "render_interpolation.h"
#ifdef CASTLE_GAMEPLAY
#include "castle_gameplay.h"
static castle_controller_t controller;
#endif
static player_t player;
static animation_t animation;
static animation_matrix_t joints[GAME_ANIMATION_JOINTS];
static scene_vertex_t posed[GAME_ANIMATION_VERTICES];
static scene_vertex_t pose_previous[GAME_ANIMATION_VERTICES],pose_current[GAME_ANIMATION_VERTICES];
static player_t render_previous_player;
static game_view_t render_previous_view;
static game_view_t view;
static camera_orbit_t camera;
// Original radial/8-direction camera uses a 1000-unit base distance and
// 125-unit eye focus. Interiors use a shorter boom to fit their rooms.
static const camera_orbit_config_t outdoor_camera={1000,125,20,1000,2,3,16};
static const camera_orbit_config_t indoor_camera={800,125,20,1000,2,3,16};
#define CASTLE_DEFAULT_PITCH (-16)
static uint32_t current_area,previous_buttons,transition_cooldown;
static uint32_t pending_event,pending_ticks;
static void render_capture(uint32_t reset_history) {
    animation_pose(&animation,&game_animation_package,joints,pose_current);
    for(uint32_t i=0;i<GAME_ANIMATION_VERTICES;++i) {
        pose_current[i].x=(int16_t)(pose_current[i].x*4);
        pose_current[i].y=(int16_t)(pose_current[i].y*4);
        pose_current[i].z=(int16_t)(pose_current[i].z*4);
        if(reset_history)pose_previous[i]=pose_current[i];
    }
    if(reset_history){render_previous_player=player;render_previous_view=view;}
}
volatile player_t game_player;
volatile uint32_t castle_area,castle_mission_state;
volatile uint32_t castle_exit_event;
volatile uint32_t castle_pose_upload_cycles,castle_prepare_cycles,castle_draw_cycles;
static void camera_update(void) {
    DETAIL_START(camera_start);
    player_t origin={0};
    game_view_update(&view,&origin,0,castle_rotations);
    camera_world_t cw={world_areas[current_area].camera_surfaces,world_areas[current_area].camera_count};
    const camera_orbit_config_t *cfg=current_area>=1 && current_area<=3?&indoor_camera:&outdoor_camera;
    camera_orbit_step(&camera,&player,cfg,&cw,view.view,4);
    DETAIL_END(PROFILE_CAMERA,camera_start);
}
static void enter_area(uint32_t area,const int16_t arrival[3],uint8_t yaw) {
    current_area=area;world_select(world_areas+area,&player);
    player.x=arrival[0];player.y=arrival[1];player.z=arrival[2];player.grounded=0;
    view.yaw=yaw;view.pitch=CASTLE_DEFAULT_PITCH;camera.initialized=0;
    transition_cooldown=15;pending_event=pending_ticks=0;
    world_collision(world_areas+area,&player);
    animation_reset(&animation,&player,&game_animation_package);
#ifdef CASTLE_GAMEPLAY
    castle_controller_reset(&controller,&player);castle_gameplay_enter(area);
#endif
}
int game_port_init(void) {
    current_area=previous_buttons=transition_cooldown=0;view.yaw=128;view.pitch=CASTLE_DEFAULT_PITCH;
    camera.initialized=0;
    pending_event=pending_ticks=castle_exit_event=0;
    world_select(world_areas,&player);
    animation_reset(&animation,&player,&game_animation_package);
#ifdef CASTLE_GAMEPLAY
    castle_gameplay_init();castle_controller_reset(&controller,&player);
#endif
    castle_mission_state=0;camera_update();render_capture(1);return 0;
}
void game_port_update(uint32_t word) {
    uint32_t old_area=current_area,old_respawns=player.respawns;
    render_previous_player=player;render_previous_view=view;
    for(uint32_t i=0;i<GAME_ANIMATION_VERTICES;++i)pose_previous[i]=pose_current[i];
    game_input_t input;game_input_decode(&input,word);
    if(input.has_look) {
        view.yaw=input.yaw;view.pitch=CASTLE_DEFAULT_PITCH+input.pitch;
        if(view.pitch< -32)view.pitch=-32;if(view.pitch>0)view.pitch=0;
    }
    world_collision(world_areas+current_area,&player);
#ifdef CASTLE_GAMEPLAY
    if(!pending_ticks && !castle_gameplay_frozen())castle_controller_step(&controller,&player,world_areas+current_area,current_area==4,game_movement_keys(&input,view.yaw),input.buttons,game_movement_heading(&input,view.yaw));
    if(player.respawns!=old_respawns){castle_controller_reset(&controller,&player);castle_gameplay_enter(current_area);}
    uint32_t mission_event=castle_gameplay_step(&player,current_area,input.buttons,controller.action);
    castle_mission_state=castle_gameplay_mission();
    if(mission_event && !pending_ticks){pending_event=castle_exit_event=mission_event;pending_ticks=20;}
#else
    player_step(&player,world_areas[current_area].physics,game_movement_keys(&input,view.yaw));
#endif
    if(pending_ticks) {
        if(!--pending_ticks) {
            const world_exit_t *exit=world_exit_find(castle_exits,CASTLE_EXIT_COUNT,current_area,pending_event);
            if(exit)enter_area(exit->destination_area,exit->arrival,exit->yaw);
            else pending_event=0;
        }
    }else if(transition_cooldown)--transition_cooldown;
    else {
        world_contact_t contact;
        if(world_floor_contact(world_areas+current_area,&player,&contact) && contact.surface) {
            uint32_t event=castle_floor_event(contact.surface->type,player.y,contact.height);
            if(event) {
                // level_update.c falls back to F1 when the area has no F3.
                const world_exit_t *exit=world_exit_find(castle_exits,CASTLE_EXIT_COUNT,current_area,event);
                if(!exit) {event=CASTLE_EXIT_DEATH;exit=world_exit_find(castle_exits,CASTLE_EXIT_COUNT,current_area,event);}
                if(exit) {pending_event=castle_exit_event=event;pending_ticks=20;}
            }
        }
        int32_t i=world_transition_find(castle_transitions,CASTLE_TRANSITION_COUNT,current_area,&player,
            (input.buttons&GAME_USE)&&!(previous_buttons&GAME_USE),
#ifdef CASTLE_GAMEPLAY
            castle_gameplay_stars(),castle_gameplay_keys());
#else
            70,3);
#endif
        if(i>=0 && !pending_event) {
            const world_transition_t *t=castle_transitions+i;
            enter_area(t->destination_area,t->arrival,t->yaw);
        }
    }
    previous_buttons=input.buttons;
    DETAIL_START(animation_start);
#ifdef CASTLE_GAMEPLAY
    if(controller.action==CASTLE_ACTION_SLIDE)animation_step_clip(&animation,&player,&game_animation_package,4,6);
    else if(controller.action==CASTLE_ACTION_GROUND_POUND)animation_step_clip(&animation,&player,&game_animation_package,5,6);
    else
#endif
    animation_step(&animation,&player,&game_animation_package);
    DETAIL_END(PROFILE_ANIMATION_STEP,animation_start);
#ifdef CASTLE_PROFILE_FIXED_POSE
    // Benchmark fixture only: original idle start pose, independent of FPS.
    animation.clip=ANIMATION_IDLE;
    animation.phase=(uint32_t)game_animation_package.clips[ANIMATION_IDLE].start<<8;
#endif
    camera_update();
    render_capture(old_area!=current_area || old_respawns!=player.respawns);
    game_player.x=player.x;game_player.y=player.y;game_player.z=player.z;
    game_player.grounded=player.grounded;game_player.velocity_y=player.velocity_y;
    game_player.facing=player.facing;game_player.previous_keys=player.previous_keys;game_player.respawns=player.respawns;
    castle_area=current_area;
}
static int render_frame(uint32_t frame,uint32_t alpha) {
    uint32_t start=SOC_CYCLES;
    player_t render_player=player;game_view_t render_view=view;
    render_player.x=game_render_lerp(render_previous_player.x,player.x,alpha);
    render_player.y=game_render_lerp(render_previous_player.y,player.y,alpha);
    render_player.z=game_render_lerp(render_previous_player.z,player.z,alpha);
    int32_t yaw=(int32_t)view.yaw,old_yaw=(int32_t)render_previous_view.yaw;
    int32_t yaw_delta=((yaw-old_yaw+128)&255)-128;
    render_view.yaw=(uint32_t)game_render_lerp(old_yaw,old_yaw+yaw_delta,alpha)&255u;
    render_view.pitch=game_render_lerp(render_previous_view.pitch,view.pitch,alpha);
    player_t origin={0};game_view_update(&render_view,&origin,0,castle_rotations);
    for(uint32_t i=3;i<12;i+=4)render_view.view[i]=(int16_t)game_render_lerp(render_previous_view.view[i],view.view[i],alpha);
    for(uint32_t i=0;i<GAME_ANIMATION_VERTICES;++i) {
        posed[i].x=(int16_t)game_render_lerp(pose_previous[i].x,pose_current[i].x,alpha);
        posed[i].y=(int16_t)game_render_lerp(pose_previous[i].y,pose_current[i].y,alpha);
        posed[i].z=(int16_t)game_render_lerp(pose_previous[i].z,pose_current[i].z,alpha);
    }
    uint32_t offset=0;
    for(uint32_t h=0;h<PORTABLE_MESH_COUNT;++h) {
        if(game_mesh_frame((uint8_t)h,posed+offset,portable_meshes[h].vertex_count))return -1;
        offset+=portable_meshes[h].vertex_count;
    }
    castle_pose_upload_cycles=SOC_CYCLES-start;start=SOC_CYCLES;
    if(world_prepare(world_areas+current_area,&render_player,render_view.view,PORTABLE_MESH_COUNT))return -1;
    castle_prepare_cycles=SOC_CYCLES-start;start=SOC_CYCLES;
    if(gfx_identity_view() || gfx_begin_frame(frame))return -1;
    if(world_draw(world_areas+current_area,&render_player,render_view.view,PORTABLE_MESH_COUNT))return -1;
    int32_t angle=(int32_t)((player.facing<<3)&255),previous=(int32_t)((render_previous_player.facing<<3)&255);
    int32_t delta=((angle-previous+128)&255)-128;
    uint32_t facing=(uint32_t)game_render_lerp(previous,previous+delta,alpha)&255u;
    int32_t co=castle_rotations[facing][0],si=castle_rotations[facing][1];
    int16_t model[12];
    for(uint32_t row=0;row<3;++row) {
        uint32_t b=row<<2;
        model[b]=(int16_t)((fixed_mul(render_view.view[b],co)-fixed_mul(render_view.view[b+2],si))>>8);
        model[b+1]=render_view.view[b+1];
        model[b+2]=(int16_t)((fixed_mul(render_view.view[b],si)+fixed_mul(render_view.view[b+2],co))>>8);
        model[b+3]=render_view.view[b+3];
    }
    for(uint32_t h=0;h<PORTABLE_MESH_COUNT;++h)if(gfx_draw_matrix((uint8_t)h,model))return -1;
#ifdef CASTLE_GAMEPLAY
    if(castle_gameplay_draw(current_area,&render_player,&render_view))return -1;
#endif
    castle_draw_cycles=SOC_CYCLES-start;
    return gfx_end_frame();
}
int game_port_render(uint32_t frame) { return render_frame(frame,65536u); }
int game_port_render_interpolated(uint32_t frame,uint32_t alpha) { return render_frame(frame,alpha); }
